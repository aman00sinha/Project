package packagecompletedetail;

import java.util.List;

public interface PackagecompleteManager {

	List<Packagecompletedetail> getPackagedetail();
}

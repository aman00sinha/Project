package packagecompletedetail;

import java.util.List;

public interface PackagecompletedetailDAO {

	List<Packagecompletedetail> getPackagedetail();

}

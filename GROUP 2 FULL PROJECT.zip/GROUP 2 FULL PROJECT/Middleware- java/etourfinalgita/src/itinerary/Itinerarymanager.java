package itinerary;

import java.util.List;



public interface Itinerarymanager {

	List<Itinerary> getitinerary();


}

package itinerary;

import java.util.List;

public interface ItineraryDAO {
	List<Itinerary> getitinerary();

}

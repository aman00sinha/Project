package datepackagedetail;

import java.util.List;

public interface DatepackageDAO {
	List<Datepackagedetail> getdate();
}

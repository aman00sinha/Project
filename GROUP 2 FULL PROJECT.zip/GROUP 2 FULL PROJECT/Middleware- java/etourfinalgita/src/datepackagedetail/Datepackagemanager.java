package datepackagedetail;

import java.util.List;

public interface Datepackagemanager {
	List<Datepackagedetail> getdate();
}

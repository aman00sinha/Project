import { Pricedetail } from './pricedetail';

describe('Pricedetail', () => {
  it('should create an instance', () => {
    expect(new Pricedetail()).toBeTruthy();
  });
});

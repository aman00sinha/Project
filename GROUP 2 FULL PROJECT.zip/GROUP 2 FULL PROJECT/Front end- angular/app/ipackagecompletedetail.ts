export interface Ipackagecompletedetail 
{
  

    packageid:number; 
    tourname:string;  
    tourimage:string;
    catsubid:number;
    description:string;
    categorysubcategory: any;

}

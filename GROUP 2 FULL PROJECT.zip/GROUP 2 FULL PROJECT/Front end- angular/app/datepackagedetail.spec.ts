import { Datepackagedetail } from './datepackagedetail';

describe('Datepackagedetail', () => {
  it('should create an instance', () => {
    expect(new Datepackagedetail()).toBeTruthy();
  });
});

export interface Idatepackagedetail {
  packagecompletedetail: any;
  datepackageid:number;
  startdate:Date;
  enddate:string;
  packageid:number;



}

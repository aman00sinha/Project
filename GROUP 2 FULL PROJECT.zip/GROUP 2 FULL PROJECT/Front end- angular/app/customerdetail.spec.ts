import { Customerdetail } from './customerdetail';

describe('Customerdetail', () => {
  it('should create an instance', () => {
    expect(new Customerdetail()).toBeTruthy();
  });
});

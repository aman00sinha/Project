export interface Ipassenger {

     bookingid:number,
     passengername:string,
     passengerdob ?:Date,
     roomtype:string,
     cost:number,
     passengeriddocument:string,
     passengeridno:string,
     passengersex:string,
     passengeremail:string;

}

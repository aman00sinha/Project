export interface Ipricedetail {
  packagecompletedetail: any;
}

export interface Isubcategory {

    subcategoryname:string;
    subcategoryimage:string;
    eofflag:string;
}

import { Categorysubcategory } from './categorysubcategory';

describe('Categorysubcategory', () => {
  it('should create an instance', () => {
    expect(new Categorysubcategory()).toBeTruthy();
  });
});

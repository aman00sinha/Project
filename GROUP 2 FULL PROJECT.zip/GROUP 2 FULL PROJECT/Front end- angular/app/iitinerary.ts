export interface Iitinerary {
  packagecompletedetail: any;
    itrid:number;
    packageid:number;
    location:string;
    daywisedescription:string;
    daynumber:number
}

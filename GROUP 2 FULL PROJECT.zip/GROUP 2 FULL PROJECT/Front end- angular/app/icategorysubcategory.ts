export interface Icategorysubcategory {
    catsubid:number;
    categoryid:number;
    categoryname:string;
    categoryimage:string;
    subcategoryid:number;
    subcategoryname:string;
    subcategoryimage:string;
    eofflag:string;    
}

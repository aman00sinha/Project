import { Packagecompletedetail } from './packagecompletedetail';

describe('Packagecompletedetail', () => {
  it('should create an instance', () => {
    expect(new Packagecompletedetail()).toBeTruthy();
  });
});

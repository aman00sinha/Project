export interface Ilogin {

customername:string;
password:string;
}

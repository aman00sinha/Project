import { Passengerdetail } from './passengerdetail';

describe('Passengerdetail', () => {
  it('should create an instance', () => {
    expect(new Passengerdetail()).toBeTruthy();
  });
});

export class Pricedetail {
}

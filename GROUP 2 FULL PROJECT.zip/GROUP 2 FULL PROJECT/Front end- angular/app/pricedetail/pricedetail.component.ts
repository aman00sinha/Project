import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricedetail',
  templateUrl: './pricedetail.component.html',
  styleUrls: ['./pricedetail.component.css']
})
export class PricedetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
